# 🗺️ Карта проекта CyberWhale Universe

## 📂 Структура проекта

```
/src
├── /app
│   ├── App.tsx                          # Главный компонент с роутингом
│   ├── /components
│   │   ├── CosmicBackground.tsx        # Анимированный космический фон
│   │   ├── Navigation.tsx              # Навигационное меню
│   │   └── UnderDevelopment.tsx        # Заглушка для разделов в разработке
│   └── /pages
│       ├── HomePage.tsx                 # Главная страница (лендинг)
│       ├── AuthPage.tsx                 # Регистрация/Вход
│       ├── DashboardPage.tsx            # Личный кабинет
│       ├── LearningPage.tsx             # Список курсов
│       ├── CourseCatalogPage.tsx        # Расширенный каталог курсов
│       ├── CoursePage.tsx               # Страница курса с модулями
│       ├── LessonPage.tsx               # Страница урока с тестом
│       ├── CTFPage.tsx                  # Список CTF задач
│       ├── CTFChallengePage.tsx         # Страница CTF задачи
│       ├── LeaderboardPage.tsx          # Таблица лидеров
│       ├── CareerPage.tsx               # Карьера (заглушка)
│       ├── AIAgentsPage.tsx             # ИИ-агенты (заглушка)
│       ├── CommunityPage.tsx            # Сообщество (заглушка)
│       └── AdminPage.tsx                # Админ-панель
└── /styles
    ├── fonts.css                        # Импорт шрифтов
    ├── theme.css                        # Цветовая схема
    └── index.css                        # Глобальные стили + prose
```

## 🛤️ Маршруты

| Маршрут | Компонент | Описание |
|---------|-----------|----------|
| `/` | HomePage | Главная страница |
| `/auth` | AuthPage | Регистрация и вход |
| `/dashboard` | DashboardPage | Личный кабинет |
| `/learning` | LearningPage | Список курсов |
| `/courses` | CourseCatalogPage | Расширенный каталог |
| `/course/:courseId` | CoursePage | Детали курса |
| `/lesson/:lessonId` | LessonPage | Страница урока |
| `/ctf` | CTFPage | Список CTF задач |
| `/ctf/:challengeId` | CTFChallengePage | CTF задача |
| `/leaderboard` | LeaderboardPage | Рейтинг |
| `/career` | CareerPage | Карьера |
| `/ai` | AIAgentsPage | ИИ-агенты |
| `/community` | CommunityPage | Сообщество |
| `/admin` | AdminPage | Админ-панель |

## 🎨 Дизайн-система

### Цвета
```css
--background: #111927        /* Основной фон */
--primary: #9fef00          /* HackTheBox зелёный */
--secondary: #3b82f6        /* Синий акцент */
--foreground: #e4e4e7       /* Основной текст */
--muted-foreground: #94a3b8 /* Приглушённый текст */
--border: rgba(71, 85, 105, 0.3) /* Границы */
```

### Шрифты
- **Заголовки**: Orbitron (400-900)
- **Текст**: Roboto Mono (300-700)

### Эффекты
- Glassmorphism: `backdrop-blur-sm bg-card/60`
- Градиенты: `from-primary to-secondary`
- Тени: `0 0 30px rgba(159, 239, 0, 0.3)`

## 🔄 User Flow

### Новичок начинает обучение
```
/ → /auth → /dashboard → /learning → /course/1 → /lesson/1
```

### Пользователь решает CTF
```
/dashboard → /ctf → /ctf/1 → Submit flag → /leaderboard
```

### Админ добавляет контент
```
/auth (admin) → /admin → Create course → Add lessons → Publish
```

## 🎯 Ключевые компоненты

### CosmicBackground
- Анимированные звёзды
- Светящиеся орбы
- Сетка координат

### Navigation
- Адаптивное меню
- Мобильный hamburger
- Подсветка активной страницы

### UnderDevelopment
- Анимированный робот
- Прогресс-бар
- Email форма для уведомлений

## 💡 Рекомендации по использованию

1. **Начните с главной страницы** (`/`) для понимания концепции
2. **Изучите формы** в `/auth` для примеров валидации
3. **Откройте дашборд** (`/dashboard`) для навигации по функционалу
4. **Попробуйте курсы** (`/learning` → `/course/1` → `/lesson/1`)
5. **Проверьте CTF** (`/ctf` → `/ctf/1`)
6. **Посмотрите лидерборд** (`/leaderboard`)
7. **Зайдите в админку** (`/admin`) для управления

## 🔧 Кастомизация

### Изменение цветов
Отредактируйте `/src/styles/theme.css`:
```css
:root {
  --primary: #ваш_цвет;
  --secondary: #ваш_цвет;
}
```

### Добавление новой страницы
1. Создайте файл в `/src/app/pages/`
2. Добавьте маршрут в `/src/app/App.tsx`
3. Добавьте пункт в Navigation (если нужно)

### Изменение mock данных
Все mock данные находятся в useState хуках компонентов страниц. Просто измените значения в массивах.

## 📱 Адаптивность

- Используйте Tailwind breakpoints: `md:`, `lg:`
- Проверяйте на разных разрешениях
- Мобильное меню автоматически активируется на `< lg` (1024px)

## 🚀 Следующие шаги

1. Подключить реальный backend/API
2. Добавить систему аутентификации
3. Реализовать разделы Career, AI, Community
4. Добавить больше курсов и CTF задач
5. Внедрить систему достижений
6. Создать реальные видео-уроки
